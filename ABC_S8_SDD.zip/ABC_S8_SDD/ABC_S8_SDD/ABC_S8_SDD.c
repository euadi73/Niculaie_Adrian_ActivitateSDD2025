#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <malloc.h>


typedef struct Vacanta {

	char* destinatie;
	int pret;

}vacanta;

vacanta citireVacanta(FILE* f) {

	vacanta v;
	char buffer[30];

	fscanf(f, "%s", buffer);

	v.destinatie = (char*)malloc(sizeof(char) * (strlen(buffer) + 1));
	strcpy(v.destinatie, buffer);

	fscanf(f, "%d", &v.pret);

	return v;
}

vacanta creareVacanta(const char* destinatie, int pret) {

	vacanta v;

	v.destinatie = (char*)malloc(sizeof(char) * (strlen(destinatie) + 1));
	strcpy(v.destinatie, destinatie);

	v.pret = pret;

	return v;
}

void afisareVacanta(vacanta v) {

	printf("\n Vacanta are destinatia %s si pretul %d", v.destinatie, v.pret);

}

typedef struct Nod {

	struct nod* st;
	struct nod* dr;
	vacanta info;

}nod;

nod* creareNod(vacanta info, nod* st, nod* dr) {

	nod* nou = (nod*)malloc(sizeof(nod));
	nou->info = creareVacanta(info.destinatie, info.pret);
	nou->st = st;
	nou->dr = dr;

	return nou;
}

nod* inserareABC(nod* root, vacanta v) {

	if (root) {

		if (v.pret < root->info.pret) {

			root->st = inserareABC(root->st, v);

		}
		else if (v.pret > root->info.pret) {

			root->dr = inserareABC(root->dr, v);

		}return root;
	}
	else return creareNod(v, NULL, NULL);

}


void SRD(nod* root) {

	if (root) {

		SRD(root->st);
		afisareVacanta(root->info);
		SRD(root->dr);

	}
}

void RSD(nod* root) {

	if (root) {

		afisareVacanta(root->info);
		RSD(root->st);
		RSD(root->dr);

	}
}

void SDR(nod* root) {

	if (root) {

		SDR(root->st);
		SDR(root->dr);
		afisareVacanta(root->info);
	}
}

void dezalocare(nod** root) {

	if (*root) {

		dezalocare(&(*root)->st);
		dezalocare(&(*root)->dr);

		free((*root)->info.destinatie);
		free(*root);
		*root = NULL;
	}

}

int maxim(int a, int b) {

	return(a > b) ? a : b;
}


int inaltimeArbore(nod* root) {

	if (root) {
		return 1 + maxim(inaltimeArbore(root->st), inaltimeArbore(root->dr));
	}
	else return 0;
}


int gradEchilibru(nod* root) {

	return inaltimeArbore(root->st) - inaltimeArbore(root->dr);

}

nod* rotireStanga(nod* root) {

	nod* aux = root->dr;
	root->dr = aux->st;
	aux->st = root;

	return aux;
}


nod* rotireDreapta(nod* root) {
	nod* aux = root->st;
	root->st = aux->dr;
	aux->dr = root;
	return aux;
}


nod* inserareAVL(nod* root, vacanta v) {

	if (root) {

		if (v.pret < root->info.pret) {

			root->st = inserareAVL(root->st, v);

		}
		else if (v.pret > root->info.pret) {

			root->dr = inserareAVL(root->dr, v);

		}
		
		//reechilibrare

		int ge = gradEchilibru(root);
		if (ge == -2) { // daca gradul este -2 => dezechilibru pe dreapta

			if (gradEchilibru(root->dr) == -1) {// dezechilibru usor
				root = rotireStanga(root);
			}
			else {	//dezechilibru complicat, avem nevoie de 2 rotiri
				root->dr = rotireDreapta(root->dr);
				root = rotireStanga(root);
			}

		}


		if (ge == 2) { // daca gradul este 2 => dezechilibru pe stanga

			if (gradEchilibru(root->st) == 1) {   // dezechilibru usor
				root = rotireDreapta(root);
			}
			else {	//dezechilibru complicat, avem nevoie de 2 rotiri
				root->st = rotireStanga(root->st);
				root = rotireDreapta(root);
			}

		}

		
		return root;
	}
	else return creareNod(v, NULL, NULL);

}



void numarNoduri(nod* root, int *nr) {

	if (root) { //RSD
		(*nr)++;
		numarNoduri(root->st, nr);
		numarNoduri(root->dr, nr);

	}

}

void cautareVacantaDupaDestinatie(nod* root, const char* destinatie, vacanta* v) {

	if (root) {
		if (strcmp(root->info.destinatie, destinatie) == 0) {
			*v = root->info;
		}
		
		cautareVacantaDupaDestinatie(root->dr, destinatie, v);
		cautareVacantaDupaDestinatie(root->st, destinatie, v);


	}

}

void cautareVacantaDupaPret(nod* root, int pret, vacanta* v) {

	if (root) {
		if (pret == root->info.pret) {
			*v = root->info;

		}
		if (pret < root->info.pret) {

			cautareVacantaDupaPret(root->st, pret, v);

		}
		if (pret > root->info.pret) {

			cautareVacantaDupaPret(root->dr, pret, v);
		}

	}

}


nod* citireArbore(FILE* f) {

	int nr = 0;

	fscanf(f, "%d", &nr);

	nod* root = NULL;

	for (int i = 0; i < nr; i++) {
		//root = inserareABC(root, citireVacanta(f));
		root = inserareAVL(root, citireVacanta(f));
	}
	return root;
}


void main() {

	/*nod* root = NULL;

	root = inserareABC(root, creareVacanta("Italia", 20));
	root = inserareABC(root, creareVacanta("Grecia", 15));
	root = inserareABC(root, creareVacanta("Franta", 30));
	root = inserareABC(root, creareVacanta("Portugalia", 17));
	root = inserareABC(root, creareVacanta("Bulgaria", 14));
	root = inserareABC(root, creareVacanta("Germania", 40));*/

	FILE* f = fopen("Vacante.txt", "r");
	nod* root = citireArbore(f);



	SRD(root);

	printf("\n Inaltimea arborelui este %d", inaltimeArbore(root));

	printf("\n----------------------------------------");

	int nr = 0;
	numarNoduri(root, &nr);
	printf("\n Numarul de noduri este %d", nr);

	printf("\n----------------------------------------");

	vacanta v = creareVacanta("aaa", -1);
	cautareVacantaDupaDestinatie(root, "Grecia", &v);
	afisareVacanta(v);

	printf("\n----------------------------------------");

	vacanta v2 = creareVacanta("bbb", -1);
	cautareVacantaDupaPret(root, 20, &v2);
	afisareVacanta(v2);

	dezalocare(&root);

	printf("\n Afisare dupa dezalocare: ");
	SRD(root);


}